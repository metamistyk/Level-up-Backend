package com.level.up.levelupgamer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LevelupgamerApplicationTests {

	@Test
	void contextLoads() {
	}

}
